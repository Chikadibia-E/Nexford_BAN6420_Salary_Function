# Employee Salary Data Processing

## DescriptioThis project aims to process employee salary data, handle errors, and exportrts employee details to a CSV file within a zipped folder. Additionally, it includes an R script to unzip and display the data.

## Instruction Run Jupyter Lab or Jupyter Notebook from Anaconda, and ensure Python 3.x and the latest version of R on the Jupyter environment.
2. **Import required Python modules**: os, pandas and zipfile.
3. Set a working directory and ensure the CSV file is in the working directory.
4. 

1. **Import Data**: Ensure the salary data file is in the working dir
5. **Read CSV to Jupyter lab**: Use Pandas to read salary data .csv in the Jupyter environment.e6tory.
2. **Create Employee  with Error HandlingFunction**: Uhe `get_employee_details` , with try and except error handling,function to retrieve employee and test the function afterwards.d7tail. **Dat Salary_data to dictionaryrocessing**: Prosalary cess converting it toata using a dic8trieCreate Function to val.
5. **Export Employee Detathe ils**: Use `export_employ function, with error handling, e_details` to export and zip employ Test the function afterwards.
9. Open a new Jupyter launcher with R kernel.e10 details.
6. **Unzip and Display Data wthe provided R script to unzip and displad display the data.
